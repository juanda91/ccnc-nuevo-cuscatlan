<?php
$db = new mysqli('127.0.0.1', 'juanda91', '', 'c9', '3306');
if ($db->connect_errno > 0) {
die('Error al conectarse a la base de datos'.$db->connect_error);
} else {
die('Conectado!');
}
?>